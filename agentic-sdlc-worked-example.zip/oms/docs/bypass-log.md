# Bypass log (Lab 3.3)
Fill the **Actual** column on GitHub with what you really saw, and attach a screenshot or link.

| # | Attempt | Expected | Actual | Evidence |
| --- | --- | --- | --- | --- |
| 1 | `git push origin HEAD:lab-start` (direct push to the default branch) | Rejected: changes must be made through a pull request | | |
| 2 | PR editing `.github/workflows/tests.yml` | Merge box: review required from code owners | | |
| 3 | PR editing `.github/agents/issue-to-pr.agent.md` | Merge box: review required from code owners | | |
| 4 | PR adding `babel` to `pyproject.toml` | `no-new-deps` check fails AND code-owner review required | | |
| 5 | `git push -f origin HEAD:lab-start` | Rejected: force pushes blocked | | |

Local pre-checks (run in this repo, see the walkthrough): `scripts/codeowners_check.py` lists the files that need review; `scripts/check_no_new_deps.py` fails when a dependency is added.
