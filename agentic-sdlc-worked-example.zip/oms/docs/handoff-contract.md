# Handoff contract
Every handoff is a block in docs/agent-state/<issue>.md:

```yaml
handoff:
  from: planner
  to: implementer-orders
  objective: <one sentence>
  context_links: [issue, state file, files]     # links, not pasted code
  assumptions: [...]
  completed: [step names with commit SHAs]
  open_questions: [...]
  constraints: [no new dependencies, do not edit alembic/ without a code owner]
  acceptance: [unit tests pass, CI green]
  hop_count: <integer>                          # +1 on every handoff; at 3 the task becomes blocked
```
**Who may change what:** only the sender writes the block; the receiver may only append to open_questions and set status: blocked.
