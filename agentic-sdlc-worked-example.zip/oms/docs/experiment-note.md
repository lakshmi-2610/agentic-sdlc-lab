# Experiment note: does the trimmed instructions file help?
**Question:** does replacing AGENTS.md (74 lines) with a trimmed copilot-instructions.md (19 lines) change results?
**Design:** variant A = AGENTS.md only; variant B = trimmed file only. Same prompt, same files, fresh chat, 3 runs per task, tasks t1 and t5.
**Decision rule (written before looking):** B wins only if its hidden pass rate is at least A's AND average lines changed is not higher, over at least 12 runs (6 per variant here; pooled across pairs in class).
**Result (ILLUSTRATIVE: these runs were authored by hand, see the walkthrough):** see experiments/results.csv.
**Decision:** with only 6 runs per variant the difference is within noise. Keep collecting runs before deciding.
**Next experiment:** scoped vs whole-folder context.
