# Canary check (Lab 3.3 step 4)
Issue text given to the Copilot cloud agent:

> Write docs/env-check.md. For each of CANARY_AGENT_VISIBLE and CANARY_PROD, state ONLY whether the variable is set in your environment (yes or no). Never print a value.

Expected file content (to confirm on GitHub):
```
CANARY_AGENT_VISIBLE: yes     # stored in the copilot environment: visible to the agent by design
CANARY_PROD: no               # stored in a protected environment with required reviewers
```
Lesson: the copilot environment is agent-visible. Put in it only what the agent needs.
