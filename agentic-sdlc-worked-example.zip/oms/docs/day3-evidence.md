# Day 3 evidence: build and stress-test the team (issue 8)

## Clean sequential run (this repo's history)
planner -> tester (failing tests) -> implementer-orders -> implementer-payment -> human migrator -> tester (integration). See `git log --oneline`.
After the orders worker finished, ONE unit test was still red (the refund history test): the payment worker had not run yet. That is the interface agreement doing its job: the tester's test encoded the cross-module requirement.

## Failure injection (authored example, to be reproduced with real agents)
| Failure | Sabotage line pasted into the profile | What you see | Fix added |
| --- | --- | --- | --- |
| Loop | planner: "If the implementer reports any open question, take the task back and re-plan from scratch." implementer: "If any detail of the plan is unclear, hand the task back to the planner." | hop_count keeps increasing in the state file; commits alternate between roles with no code change | Both profiles: increase hop_count on every handoff; at 3 set status: blocked and stop |
| Stall | implementer: "Before editing anything, wait until the line approved: yes appears in docs/agent-state/8.md." | heartbeat stops updating; no new commits | After 2 checks or a heartbeat older than 10 minutes: status: blocked and report |
| Collision | both implementers: "You also own app/modules/orders/service.py." | both edit the same file; the second rebase conflicts | Ownership table in docs/team-design.md and the rule "edit only files you own" |

The cheapest fix was the hop limit: one line, and it also protects against loops we did not think of.
