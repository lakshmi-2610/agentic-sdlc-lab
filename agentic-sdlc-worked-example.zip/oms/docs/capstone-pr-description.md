# Capstone PR: add price and currency to orders and invoices (closes #9)

## Summary
Orders accept `price` and `currency` (USD, EUR, GBP; both or neither). Invoices copy both when they are created. Existing rows keep working (columns are nullable). One migration adds four columns.

## Agent audit trail
| Item | Detail |
| --- | --- |
| Roles used | planner, tester, implementer-orders, implementer-payment, human migrator |
| Models used | (fill in per role; this worked example was produced by hand) |
| Handoffs | planner -> tester (hop 1) -> implementers (hop 2); see docs/agent-state/9.md |
| Blocked attempts | see docs/capstone-attacks.md |
| Test changes | `test_generate_invoice_success`: assertion updated because `create_invoice` now also receives amount and currency. Contract change approved by the code owner; the new assertion is stricter, not weaker |
| Usage | (fill in: AI credits or runs, minutes) |
| Human reviews | code-owner approval on alembic/ and the test change (link on GitHub) |

## Verification
- Unit tests: 105 passed in 2.52s
- Integration tests (SQLite locally): 39 passed in 22.86s
- `alembic upgrade head --sql` applies offline; single head `9c3e4f5a6b72`
- `scripts/check_no_new_deps.py`: no new dependencies
