# Issue 4 as a 10-line contract (replaces a long thread)
**Goal:** POST /payment/refund/{order_id} refunds a PAID invoice.
**Behaviour:** invoice -> CANCELLED, order -> CANCELLED via OrderStateMachine.
**Errors:** 404 no invoice; 400 invoice not paid; 400 order cannot be cancelled (SHIPPED, DELIVERED).
**In scope:** app/modules/payment/, tests/unit/test_payment.py, tests/integration/test_payment.py, README.
**Out of scope:** schema changes, migrations, new dependencies.
**Acceptance:** failing tests first; unit and integration suites green.
**Stop and ask if:** a schema change looks necessary.
