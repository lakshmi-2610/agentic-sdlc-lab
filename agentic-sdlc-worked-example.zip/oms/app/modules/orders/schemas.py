from datetime import datetime
from decimal import Decimal
from typing import Literal
from pydantic import BaseModel, ConfigDict, model_validator
from .models import OrderStatus


Currency = Literal["USD", "EUR", "GBP"]


class OrderCreate(BaseModel):
    item: str
    price: Decimal | None = None
    currency: Currency | None = None

    @model_validator(mode="after")
    def price_needs_currency(self):
        if (self.price is None) != (self.currency is None):
            raise ValueError("price and currency must be given together")
        return self


class OrderUpdate(BaseModel):
    """Partial update schema for orders. Only provided fields are applied."""
    item: str | None = None
    status: OrderStatus | None = None


class OrderRead(BaseModel):
    id: int
    user_id: int
    item: str
    status: OrderStatus
    price: Decimal | None = None
    currency: str | None = None

    model_config = ConfigDict(from_attributes=True)


class PaginatedOrders(BaseModel):
    items: list[OrderRead]
    total: int
    page: int
    page_size: int


class OrderHistoryRead(BaseModel):
    id: int
    order_id: int
    status: OrderStatus
    changed_at: datetime

    model_config = ConfigDict(from_attributes=True)
