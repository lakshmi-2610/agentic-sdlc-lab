def _headers(client):
    client.post("/users/register", json={"username": "pricing_user", "password": "testpassword123"})
    token = client.post("/users/login", json={"username": "pricing_user", "password": "testpassword123"}).json()["access_token"]
    return {"Authorization": f"Bearer {token}"}


def test_order_with_price_and_currency(client):
    headers = _headers(client)
    response = client.post("/orders/", json={"item": "laptop", "price": "19.99", "currency": "EUR"}, headers=headers)
    assert response.status_code == 200
    body = response.json()
    assert body["price"] == "19.99" and body["currency"] == "EUR"
    assert client.get(f"/orders/{body['id']}", headers=headers).json()["currency"] == "EUR"


def test_invoice_copies_price_and_currency(client):
    headers = _headers(client)
    order_id = client.post("/orders/", json={"item": "laptop", "price": "19.99", "currency": "GBP"}, headers=headers).json()["id"]
    invoice = client.post("/payment/generate", json={"order_id": order_id}, headers=headers).json()
    assert invoice["amount"] == "19.99" and invoice["currency"] == "GBP"


def test_price_without_currency_returns_422(client):
    assert client.post("/orders/", json={"item": "laptop", "price": "5"}, headers=_headers(client)).status_code == 422


def test_currency_without_price_returns_422(client):
    assert client.post("/orders/", json={"item": "laptop", "currency": "USD"}, headers=_headers(client)).status_code == 422


def test_unknown_currency_returns_422(client):
    assert client.post("/orders/", json={"item": "laptop", "price": "5", "currency": "JPY"}, headers=_headers(client)).status_code == 422


def test_existing_orders_without_price_still_work(client):
    headers = _headers(client)
    order = client.post("/orders/", json={"item": "laptop"}, headers=headers).json()
    assert order["price"] is None and order["currency"] is None
    invoice = client.post("/payment/generate", json={"order_id": order["id"]}, headers=headers).json()
    assert invoice["amount"] is None
