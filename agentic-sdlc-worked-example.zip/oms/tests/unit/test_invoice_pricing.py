from decimal import Decimal
from unittest.mock import MagicMock, patch

from app.modules.orders import models as order_models, repository as order_repository
from app.modules.payment import service, models as payment_models, repository


def test_generate_invoice_copies_price_and_currency():
    order = MagicMock(spec=order_models.Order)
    order.id, order.status = 1, order_models.OrderStatus.RECEIVED
    order.price, order.currency = Decimal("19.99"), "EUR"
    order_repo = MagicMock(spec=order_repository.OrderRepository)
    order_repo.get_order.return_value = order
    invoice_repo = MagicMock(spec=repository.InvoiceRepository)
    invoice_repo.get_invoice_by_order_id.return_value = None
    invoice_repo.create_invoice.return_value = MagicMock(spec=payment_models.Invoice)
    with patch.object(service, "_call_payment_api_create_invoice", return_value="inv-1"):
        with patch.object(service.order_service, "update_order"):
            service.generate_invoice(MagicMock(), order_repo, invoice_repo, 1)
    invoice_repo.create_invoice.assert_called_once_with(1, "inv-1", amount=Decimal("19.99"), currency="EUR")
