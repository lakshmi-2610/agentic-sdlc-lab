from decimal import Decimal
from unittest.mock import MagicMock
import pytest
from pydantic import ValidationError

from app.modules.orders import service, repository
from app.modules.orders.schemas import OrderCreate


def test_price_and_currency_together_are_valid():
    order = OrderCreate(item="laptop", price=Decimal("19.99"), currency="EUR")
    assert order.price == Decimal("19.99") and order.currency == "EUR"


def test_neither_price_nor_currency_is_valid():
    assert OrderCreate(item="laptop").price is None


def test_price_without_currency_is_rejected():
    with pytest.raises(ValidationError):
        OrderCreate(item="laptop", price=Decimal("5"))


def test_currency_without_price_is_rejected():
    with pytest.raises(ValidationError):
        OrderCreate(item="laptop", currency="USD")


def test_unknown_currency_is_rejected():
    with pytest.raises(ValidationError):
        OrderCreate(item="laptop", price=Decimal("5"), currency="JPY")


def test_create_order_passes_price_and_currency_to_the_repository():
    repo = MagicMock(spec=repository.OrderRepository)
    service.create_order(repo, 1, "laptop", Decimal("5.00"), "USD")
    repo.create_order.assert_called_once_with(1, "laptop", price=Decimal("5.00"), currency="USD")
