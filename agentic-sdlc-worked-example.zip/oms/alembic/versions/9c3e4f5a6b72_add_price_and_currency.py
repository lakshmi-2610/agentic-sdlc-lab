"""add price and currency to orders and invoices

Revision ID: 9c3e4f5a6b72
Revises: 8b2d3e4f5a61
"""
from alembic import op
import sqlalchemy as sa

revision = "9c3e4f5a6b72"
down_revision = "8b2d3e4f5a61"
branch_labels = None
depends_on = None


def upgrade() -> None:
    op.add_column("orders", sa.Column("price", sa.Numeric(12, 2), nullable=True))
    op.add_column("orders", sa.Column("currency", sa.String(3), nullable=True))
    op.add_column("invoices", sa.Column("amount", sa.Numeric(12, 2), nullable=True))
    op.add_column("invoices", sa.Column("currency", sa.String(3), nullable=True))


def downgrade() -> None:
    op.drop_column("invoices", "currency")
    op.drop_column("invoices", "amount")
    op.drop_column("orders", "currency")
    op.drop_column("orders", "price")
