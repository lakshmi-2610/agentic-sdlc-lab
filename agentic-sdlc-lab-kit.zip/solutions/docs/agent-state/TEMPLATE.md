# Agent state: issue <N>
status: in_progress            # in_progress | blocked | done
last_commit: <sha>
heartbeat: <ISO time>          # update at every step; a stale heartbeat means a stalled agent
hop_count: 0
## Plan
- [x] 1. Write failing test
- [ ] 2. Implement
- [ ] 3. Run unit tests
## Decisions (why)
- <decision> because <reason>
## Assumptions
- <assumption>
## Open questions
- <question for a human>
## Next action
<one sentence>
