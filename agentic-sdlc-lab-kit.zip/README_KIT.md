# Agentic SDLC lab kit (overlay for python-fastapi-example-oms)

Layout
- Top level (lab_mcp/, scripts/, eval/, .github/rulesets/) = STARTER files: copy these onto the lab-start branch.
- solutions/ = what participants build during the labs (devcontainer, issue form, copilot-instructions.md, agent profiles,
  CODEOWNERS, setup-steps workflow, MCP config, state template). Keep it on a `solutions` branch, not on lab-start.

Steps
1. Import https://github.com/adiffpirate/python-fastapi-example-oms into your org as `agentic-sdlc-lab-base`.
2. In a clone: `bash scripts/apply_seed.sh` (creates `lab-start` with the seeded bug and the wrong example).
3. Copy the starter files onto lab-start, commit, make lab-start the default branch, mark the repo as a template.
4. Per pair: `gh repo create <org>/lab-pair-01 --template <org>/agentic-sdlc-lab-base --private`, then run `scripts/seed_issues.sh` inside it.
5. Replace YOUR-ORG in solutions/.github/CODEOWNERS and solutions/.vscode/mcp.json when you copy them.

Verified against commit 79b3703: the seed applies cleanly, 81 unit tests still pass on lab-start, six hidden tests fail on lab-start,
the MCP server lists 4 tools and refuses the destructive one. Config files (ruleset, agent profiles, MCP JSON) are illustrative:
validate them in a pilot run.
